# Contributing to kitty-themes

We always welcome your pull request! To start contributing follow these simple
steps:

1. Fork the repo and create your branch from `master`;
2. Add your theme as config file under `themes` directory;
3. Issue the pull request through github;
